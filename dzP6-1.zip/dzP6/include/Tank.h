#pragma once

#include <stdint.h>

#include "DestroyableGroundObject.h"

#include <iostream>

#include <string>
#include <vector>


class Mediator;

class Colleague {
public:
    virtual void BeNotified( std::string message) = 0;
    static Mediator* pMediator;
};

class Mediator {
public:

    void AddColleague(Colleague* pNewColleague) {
        v.push_back(pNewColleague);
    };

    void Notify(const Colleague* from, std::string message) {
            for (Colleague* pElem : v)
            {
                if (pElem != from)
                        pElem->BeNotified(message);
            }
    }
private:
    std::vector<Colleague*> v;

};

class Tank : public DestroyableGroundObject, public Colleague
{
public:

	bool  isInside(double x1, double x2) const override;

	inline uint16_t GetScore() const override { return score; }

	void Draw() const override;

    void SomeAction() {
        pMediator->Notify(this, mes[rand()%5]);
    };
    virtual void BeNotified(std::string message) override;
    Tank(Mediator* pMed) : pMediator(pMed) { };
    Mediator* pMediator;

    std::string mes[5] = {
      "dive, dive",
      "i shoot",
      "fire, fire",
      "you hit",
      "the bombs are over"
    };

private:

	const uint16_t score = 30;

};

