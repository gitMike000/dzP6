
#include <iostream>

#include "include/Plane.h"
#include "include/MyTools.h"
#include "include/ScreenSingleton.h"

void Plane::Draw() const
{
    ScreenSingleton::getInstance().SetColor(CC_LightBlue);
    DrawBody();
    DrawWings();
    DrawTail();

//    ScreenSingleton::getInstance().SetColor(CC_LightBlue);
//    ScreenSingleton::getInstance().GotoXY(x, y);
//    std::cout << "=========>";
//    ScreenSingleton::getInstance().GotoXY(x - 2, y - 1);
//    std::cout << "===";
//    ScreenSingleton::getInstance().GotoXY(x + 3, y - 1);
//    std::cout << "\\\\\\\\";
//    ScreenSingleton::getInstance().GotoXY(x + 3, y + 1);
//    std::cout << "////";
}


void ColorPlane::DrawBody() const {
    ScreenSingleton::getInstance().SetColor(CC_LightBlue);
    ScreenSingleton::getInstance().GotoXY(x, y);
    std::cout << "=========>";
};

void ColorPlane::DrawWings() const {
    ScreenSingleton::getInstance().SetColor(CC_Yellow);
    ScreenSingleton::getInstance().GotoXY(x + 3, y - 1);
    std::cout << "\\\\\\\\";
    ScreenSingleton::getInstance().GotoXY(x + 3, y + 1);
    std::cout << "////";
};

void ColorPlane::DrawTail() const {
    ScreenSingleton::getInstance().SetColor(CC_Green);
    ScreenSingleton::getInstance().GotoXY(x - 2, y - 1);
    std::cout << "===";
};


void BigPlane::DrawBody() const {
    ScreenSingleton::getInstance().GotoXY(x, y);
    std::cout << "=======";
    ScreenSingleton::getInstance().GotoXY(x, y+1);
    std::cout << "=========>";
};

void BigPlane::DrawWings() const {
    ScreenSingleton::getInstance().GotoXY(x + 3, y - 1);
    std::cout << "\\\\\\";
    ScreenSingleton::getInstance().GotoXY(x + 3, y + 2);
    std::cout << "///";
};

void BigPlane::DrawTail() const {
    ScreenSingleton::getInstance().GotoXY(x - 2, y - 1);
    std::cout << "===";
};
